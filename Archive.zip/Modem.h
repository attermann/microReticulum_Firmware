#define SX1276 0x01
#define SX1278 0x02
#define SX1262 0x03
#define SX1280 0x04
