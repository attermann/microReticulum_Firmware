def main():
    print("Hello from microreticulum-firmware!")


if __name__ == "__main__":
    main()
